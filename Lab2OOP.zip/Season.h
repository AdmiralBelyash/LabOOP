#pragma once

enum Season
{
	Winter,
	Summer,
	Autumn,
	Spring
};
