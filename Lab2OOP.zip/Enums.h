#pragma once
#include "Color.h"
#include "Education.h"
#include "Genre.h"
#include "Phone.h"
#include "Season.h"
#include "WeekDay.h"

void DemoEnums();