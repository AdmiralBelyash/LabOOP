#pragma once

enum EducationForm
{
	INTRAMURAL,
	EXTAMURAL,
	EVENING,
	REMOTE
};