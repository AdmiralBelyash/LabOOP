#pragma once

enum  WeekDay
{
	Monday,
	Tuesday,
	Wednesday,
	Thursday,
	Friday,
	Suturday,
	Sunday
};
