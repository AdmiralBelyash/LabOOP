#pragma once

enum SmartphoneManufacturer
{
	Apple,
	Xiaomi,
	Samsung,
	Huawai,
	Motorola,
	Lenovo
};
