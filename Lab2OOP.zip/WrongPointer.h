#pragma once


void  WrongPointers();



