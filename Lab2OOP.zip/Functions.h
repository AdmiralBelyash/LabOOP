#pragma once

#include<string>
#include<exception>
#include<iostream>

#ifndef _FUNCTIONS_H_
#define _FUNCTIONS_H_

int InputInt();

int InputIndex();
#endif 

